from .vanished import *

__doc__ = vanished.__doc__
if hasattr(vanished, "__all__"):
    __all__ = vanished.__all__